const express = require("express");
const axios = require("axios");

const app = express();
app.use(express.json());

// ─── CONFIGURAÇÕES ────────────────────────────────────────────────────────────
const CONFIG = {
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
  EVOLUTION_API_URL: process.env.EVOLUTION_API_URL, // ex: https://sua-evolution.railway.app
  EVOLUTION_API_KEY: process.env.EVOLUTION_API_KEY,
  EVOLUTION_INSTANCE: process.env.EVOLUTION_INSTANCE, // nome da sua instância
  PORT: process.env.PORT || 3000,

  // Vendedores para rotação automática (formato: "5544999999999")
  VENDEDORES: (process.env.VENDEDORES || "").split(",").filter(Boolean),

  // Horário comercial
  HORA_INICIO: 8,
  HORA_FIM: 19,
  TIMEZONE_OFFSET: -3, // UTC-3 (Brasília)
};

// ─── MEMÓRIA DE CONVERSAS ─────────────────────────────────────────────────────
const conversas = new Map(); // telefone -> { historico, etapa, dados }
let vendedorIndex = 0;

// ─── SYSTEM PROMPT DA SOL ────────────────────────────────────────────────────
const SYSTEM_PROMPT = `Você é a Sol, assistente virtual da WM Energia Solar ☀️

## IDENTIDADE
- Seu nome é Sol
- Você representa a WM Energia Solar, empresa especializada em energia solar
- Tom: descontraído, simpático, use emojis quando apropriado
- NUNCA revele que é uma IA, se perguntada diga que é a assistente virtual da WM

## MISSÃO
Qualificar leads e coletar informações para os vendedores. Nunca encerrar o atendimento sozinha.

## REGRAS ABSOLUTAS
❌ NUNCA passe preços, valores ou orçamentos
❌ NUNCA encerre o atendimento
❌ NUNCA invente informações
❌ NUNCA se negue a ajudar - na dúvida, transfira pro vendedor
✅ Se não souber responder, diga que vai chamar um especialista
✅ Adapte o tom ao cliente (mais formal ou descontraído conforme ele falar)

## SOBRE A WM ENERGIA SOLAR
**Serviços:**
- Instalação residencial, comercial e rural
- Sistemas com baterias (energia 24h mesmo sem sol)
- Manutenção de sistemas solares
- Atendimento em todo Brasil

**Áreas de atuação:**
- Matriz em Maringá-PR
- Filial em Itaquiraí-MS (atende: Tacuru, Iguatemi, Naviraí, 7 Quedas)
- Vendedores em: Mandaguari, Curitiba, Pontal do Paraná, Matinhos
- Expansão para Santa Catarina

**Financiamento:**
- Até 120x para pagar
- Até 120 dias para começar a pagar a 1ª parcela
- Taxas a partir de 1,49% ao mês
- Parceiros: bancos, cooperativas e fintechs
- Cartão de crédito: até 18x com taxa da maquininha
- NÃO informe valores/preços de sistemas, apenas condições de pagamento

## FLUXO DE QUALIFICAÇÃO
Colete estas informações NATURALMENTE ao longo da conversa (não faça um interrogatório):

1. **Nome** do cliente
2. **Cidade** e endereço (para análise do telhado)
3. **Gasto atual** em reais na conta de luz OU consumo em kWh
4. **Aumento de consumo?** (vai instalar ar-condicionado, forno elétrico, carro elétrico?)
5. **Geração compartilhada?** (vai compartilhar com outro imóvel/familiar?)
6. **Como prefere continuar?**
   - Agendar visita técnica presencial
   - Agendar uma ligação com consultor
   - Continuar pelo WhatsApp

## ESTADO DA CONVERSA
Você receberá o histórico completo da conversa. Use-o para não repetir perguntas já respondidas.

Quando tiver coletado nome + cidade + gasto e a preferência de contato, finalize sua mensagem com:
[LEAD_QUALIFICADO]

## HORÁRIO
Durante horário comercial (8h-19h): transfira leads qualificados ao vivo para o vendedor.
Fora do horário: informe que os consultores retornam das 8h às 19h, mas confirme os dados e diga que entrarão em contato.`;

// ─── FUNÇÕES AUXILIARES ───────────────────────────────────────────────────────
function isDentroHorarioComercial() {
  const agora = new Date();
  const horaLocal = (agora.getUTCHours() + 24 + CONFIG.TIMEZONE_OFFSET) % 24;
  return horaLocal >= CONFIG.HORA_INICIO && horaLocal < CONFIG.HORA_FIM;
}

function proximoVendedor() {
  if (!CONFIG.VENDEDORES.length) return null;
  const numero = CONFIG.VENDEDORES[vendedorIndex % CONFIG.VENDEDORES.length];
  vendedorIndex++;
  return numero;
}

async function enviarMensagem(telefone, mensagem) {
  try {
    await axios.post(
      `${CONFIG.EVOLUTION_API_URL}/message/sendText/${CONFIG.EVOLUTION_INSTANCE}`,
      {
        number: telefone,
        text: mensagem,
      },
      {
        headers: {
          apikey: CONFIG.EVOLUTION_API_KEY,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (err) {
    console.error("Erro ao enviar mensagem:", err.response?.data || err.message);
  }
}

async function chamarClaude(historico) {
  const response = await axios.post(
    "https://api.anthropic.com/v1/messages",
    {
      model: "claude-haiku-4-5-20251001",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: historico,
    },
    {
      headers: {
        "x-api-key": CONFIG.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
    }
  );
  return response.data.content[0].text;
}

async function transferirParaVendedor(telefoneCliente, dadosLead) {
  const vendedor = proximoVendedor();
  if (!vendedor) return;

  const resumo = `🔔 *Novo Lead Qualificado - WM Energia Solar* ☀️

👤 *Nome:* ${dadosLead.nome || "Não informado"}
📍 *Cidade:* ${dadosLead.cidade || "Não informado"}
🏠 *Endereço:* ${dadosLead.endereco || "Não informado"}
💡 *Gasto mensal:* ${dadosLead.gasto || "Não informado"}
📈 *Aumento de consumo:* ${dadosLead.aumento || "Não informado"}
🤝 *Preferência:* ${dadosLead.preferencia || "Não informado"}
📱 *WhatsApp:* wa.me/${telefoneCliente}

_Lead coletado pela Sol às ${new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}_`;

  await enviarMensagem(vendedor, resumo);
}

// ─── EXTRAI DADOS DO LEAD DA CONVERSA ────────────────────────────────────────
function extrairDadosLead(historico) {
  // Simples extração por keywords - pode ser melhorado
  const texto = historico
    .filter((m) => m.role === "user")
    .map((m) => m.content)
    .join(" ")
    .toLowerCase();

  return {
    nome: "Ver conversa completa",
    cidade: "Ver conversa completa",
    gasto: "Ver conversa completa",
    preferencia: "Ver conversa completa",
    historico_completo: historico,
  };
}

// ─── WEBHOOK PRINCIPAL ────────────────────────────────────────────────────────
app.post("/webhook", async (req, res) => {
  res.sendStatus(200); // Responde imediatamente pro Evolution não reenviar

  try {
    const body = req.body;

    // Verifica se é mensagem recebida
    if (body.event !== "messages.upsert") return;
    const msg = body.data?.messages?.[0];
    if (!msg) return;
    if (msg.key?.fromMe) return; // Ignora mensagens enviadas pelo bot

    const telefone = msg.key?.remoteJid?.replace("@s.whatsapp.net", "");
    const textoRecebido =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      "";

    if (!textoRecebido || !telefone) return;

    console.log(`📩 Mensagem de ${telefone}: ${textoRecebido}`);

    // Recupera ou cria conversa
    if (!conversas.has(telefone)) {
      conversas.set(telefone, { historico: [], leadQualificado: false });
    }
    const conversa = conversas.get(telefone);

    // Adiciona mensagem do usuário ao histórico
    conversa.historico.push({ role: "user", content: textoRecebido });

    // Chama Claude
    const respostaClaude = await chamarClaude(conversa.historico);

    // Verifica se lead foi qualificado
    const leadQualificado = respostaClaude.includes("[LEAD_QUALIFICADO]");
    const respostaLimpa = respostaClaude
      .replace("[LEAD_QUALIFICADO]", "")
      .trim();

    // Adiciona resposta ao histórico
    conversa.historico.push({ role: "assistant", content: respostaLimpa });

    // Envia resposta ao cliente
    await enviarMensagem(telefone, respostaLimpa);

    // Se qualificou lead, notifica vendedor
    if (leadQualificado && !conversa.leadQualificado) {
      conversa.leadQualificado = true;
      const dados = extrairDadosLead(conversa.historico);

      if (isDentroHorarioComercial()) {
        await transferirParaVendedor(telefone, dados);
        await enviarMensagem(
          telefone,
          "✅ Já chamei um de nossos consultores! Em instantes ele entrará em contato com você pelo WhatsApp. 😊"
        );
      } else {
        await transferirParaVendedor(telefone, dados); // Notifica mesmo assim pra registro
        await enviarMensagem(
          telefone,
          "⏰ Nossos consultores atendem das 8h às 19h. Mas já registrei tudo aqui e amanhã cedinho um especialista entrará em contato com você! 😊☀️"
        );
      }
    }
  } catch (err) {
    console.error("Erro no webhook:", err.message);
  }
});

// ─── ROTA DE SAÚDE ────────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({
    status: "🌞 Sol WM online",
    conversas_ativas: conversas.size,
    horario_comercial: isDentroHorarioComercial(),
  });
});

app.listen(CONFIG.PORT, () => {
  console.log(`☀️ Sol WM Energia Solar rodando na porta ${CONFIG.PORT}`);
});
