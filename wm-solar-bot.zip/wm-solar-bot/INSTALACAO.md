# ☀️ Sol - Assistente Virtual WM Energia Solar
## Guia de Instalação Completo

---

## PASSO 1 — Criar conta no GitHub e subir o projeto

1. Acesse **github.com** e crie uma conta (se não tiver)
2. Clique em **"New repository"**
3. Nome: `wm-solar-bot` → clique em **"Create repository"**
4. Siga as instruções pra subir os arquivos (ou use o GitHub Desktop)

---

## PASSO 2 — Subir a Evolution API no Railway

1. Acesse **railway.app** e faça login com GitHub
2. Clique em **"New Project"** → **"Deploy from template"**
3. Pesquise **"Evolution API"** e selecione o template oficial
4. Clique em **"Deploy"** e aguarde (~2 minutos)
5. Vá em **Settings → Domains** e copie a URL gerada
   - Ex: `https://evolution-api-production-xxxx.railway.app`
6. Acesse essa URL no navegador → vai abrir o painel da Evolution API
7. Crie uma **instância** com o nome `wm-solar`
8. Conecte seu WhatsApp escaneando o QR Code

---

## PASSO 3 — Subir o Bot Sol no Railway

1. No Railway, clique em **"New Project"** → **"Deploy from GitHub repo"**
2. Selecione o repositório `wm-solar-bot`
3. Vá em **Variables** e adicione as seguintes variáveis:

| Variável | Valor |
|----------|-------|
| `ANTHROPIC_API_KEY` | Sua chave da API Anthropic |
| `EVOLUTION_API_URL` | URL da Evolution API (Passo 2) |
| `EVOLUTION_API_KEY` | Chave da Evolution API |
| `EVOLUTION_INSTANCE` | `wm-solar` |
| `VENDEDORES` | Números dos vendedores (ex: `5544999990001,5544999990002`) |

4. Clique em **"Deploy"**
5. Copie a URL do bot (ex: `https://wm-solar-bot-production-xxxx.railway.app`)

---

## PASSO 4 — Configurar Webhook na Evolution API

1. Acesse o painel da Evolution API
2. Vá na instância `wm-solar` → **Webhook**
3. Cole a URL do bot + `/webhook`:
   ```
   https://wm-solar-bot-production-xxxx.railway.app/webhook
   ```
4. Ative o evento **`messages.upsert`**
5. Salve

---

## PASSO 5 — Testar

1. Mande uma mensagem pro número conectado
2. A Sol deve responder em segundos ☀️
3. Verifique os logs no Railway se algo não funcionar

---

## CHAVE DA API ANTHROPIC

1. Acesse **console.anthropic.com**
2. Vá em **API Keys** → **Create Key**
3. Copie e cole no Railway como `ANTHROPIC_API_KEY`

> ⚠️ O modelo usado é o **claude-haiku** (mais barato).
> Custo estimado: R$ 2-5 por mês para volume normal de atendimentos.

---

## NÚMEROS DOS VENDEDORES

Formato: DDI + DDD + número, sem espaços ou símbolos
- Brasil: `55` + DDD + número
- Exemplo Maringá: `5544999990001`
- Vários vendedores: `5544999990001,5544999990002,5544999990003`

O bot faz rotação automática entre os vendedores cadastrados.

---

## SUPORTE

Em caso de dúvidas, verifique:
1. Logs no Railway (aba "Deployments" → "View Logs")
2. Status da Evolution API (acesse a URL dela no navegador)
3. Se o WhatsApp ainda está conectado na instância
